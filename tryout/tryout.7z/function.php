<?php 
function pemisahPilihan($data){
	$pilihan = explode("|",$data["pilihan"]);
	return $pilihan;
}

 ?>