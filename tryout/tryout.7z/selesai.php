<?php 
session_start();

if (!isset($_SESSION["user"])) {
	exit();
}
$userName = $_SESSION["user"];
include "Database.php";
include "function.php";
$db = new Database();
$db->query("SELECT * FROM soal");
$result = $db->resultAll();
$jumlahHalaman = count($result);
$kunJwb = [];
$userJwb = [];
$nilaiAkhir = 0;
$poin = 100/$jumlahHalaman;
for ($i=0; $i < $jumlahHalaman; $i++) { 
	$kunJwb[$i] = $result[$i]["jawaban"];
}
for ($i=1; $i <=$jumlahHalaman ; $i++) { 
	$sessionName = "jawabanno".$i;
	if (isset($_SESSION[$sessionName])) {
		$userJwb[$i-1] = ($_SESSION[$sessionName]);
	}else{
		$userJwb[$i-1] = 0;
	}
}
 for ($i=0; $i< $jumlahHalaman ; $i++) {
 	if ($kunJwb[$i] == $userJwb[$i]) {
 		$nilaiAkhir += $poin;
 	}
 }
$queryName = "INSERT INTO nilai VALUES (:id,:namaUser,:nilaiUser)";
$db->query($queryName);
$db->bind(':id','');
$db->bind(':namaUser',$userName);
$db->bind(':nilaiUser',$nilaiAkhir);
$db->execute();
 ?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">

    <title>Try Out Online</title>
  </head>
  <body>
  	 <nav class="navbar navbar-light bg-light border">
    <span class="navbar-brand mb-0 h1">Try Out Online</span>
  </nav>
  <?php if (isset($_SESSION["saranmasuk"])){
	  	echo "<div class='alert alert-success' role='alert'>
	 	 Saran Telah Masuk, Terima Kasih atas Sarannya</div>";
	 	 sleep(1);
  }
  ?>
  <div class="container mt-3 ">
	 	<div class="card">
	 	<div class="card-header">Nilai <b><?php echo $userName; ?> </b></div>
			<div class="card-body">
		    <h2 class="card-title"><?php echo $nilaiAkhir ?></h2>
		    <p class="card-text">Terima kasih telah mencoba, jangan lupa masukan dan sarannya ya, <?php echo $userName ?></p>
		    <a href="test.php" class="btn btn-primary">Coba Lagi</a>
		    <a href="logout.php" class="btn btn-danger">Log Out</a>
		</div>
		</div>
	</div><br>
	<div class="container bt-3">
		<div class="form-group">
			<form action="saran.php" method="post">
				<label for="exampleFormControlTextarea1">Masukan dan Saran</label>
			    <textarea class="form-control" id="saran" name="saran" rows="3"></textarea>
			    <button type="input" class="btn btn-warning mt-3" name="inputsaran">Kirim Masukan dan Saran</button>
		    </form>

		</div>
  	</div>
  	  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
    <script>
    
    </script>
  </body>
</html>