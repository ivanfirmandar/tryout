<?php 

session_start();
include "Database.php";
include "function.php";
$userName = $_SESSION["user"];
$db = new Database();
if (isset($_POST["inputsaran"])) {
	$namaUser = $userName;
	$saranUser = $_POST["saran"];
	$queryName = "INSERT INTO saran VALUES (:id,:namaUser,:saranUser)";
	$db->query($queryName);
	$db->bind(':id','');
	$db->bind(':namaUser',$namaUser);
	$db->bind(':saranUser',$saranUser);
	$db->execute();
	$_SESSION["saranmasuk"] = true;


}
header("location: selesai.php");



 ?>